import { initializeApp } from "https://www.gstatic.com/firebasejs/11.3.1/firebase-app.js";
import { getDatabase, ref, get, update } from "https://www.gstatic.com/firebasejs/11.3.1/firebase-database.js";

const firebaseConfig = {
    apiKey: "AIzaSyDQffM652v27YDAnfq1KggkPMlJd_ZGCQ0",
    authDomain: "flash-ai-s1.firebaseapp.com",
    projectId: "flash-ai-s1",
    storageBucket: "flash-ai-s1.appspot.com",
    messagingSenderId: "461153919599",
    appId: "1:461153919599:web:5db1f03555129a84f6239a",
    measurementId: "G-HPM72Y2LWH"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

window.showLoadingAlert = function () {
    let loadingAlert = document.createElement("div");
    loadingAlert.id = "loadingAlert";
    loadingAlert.innerHTML = `
        <div class="custom-loading">
            <div class="loader"></div>
        </div>
    `;
    document.body.appendChild(loadingAlert);
};

window.closeLoadingAlert = function () {
    let loadingAlert = document.getElementById("loadingAlert");
    if (loadingAlert) {
        document.body.removeChild(loadingAlert);
    }
};

window.showCustomAlert = function (message, isWelcome = false) {
    let alertBox = document.createElement("div");
    alertBox.id = "customAlert";
    alertBox.innerHTML = `
        <div class="custom-alert ${isWelcome ? 'welcome-alert' : ''}">
            <h3>FLASH AI S2</h3>
            <p>${message}</p>
            <button onclick="closeCustomAlert()">OK</button>
        </div>
    `;
    document.body.appendChild(alertBox);
};

window.closeCustomAlert = function () {
    let alertBox = document.getElementById("customAlert");
    if (alertBox) {
        document.body.removeChild(alertBox);
    }
};

function saveKeyToLocalStorage(key) {
    localStorage.setItem("flashAiS2Key", key);
}

function getKeyFromLocalStorage() {
    return localStorage.getItem("flashAiS2Key");
}

function clearKeyFromLocalStorage() {
    localStorage.removeItem("flashAiS2Key");
}

function saveCheckboxState(state) {
    localStorage.setItem("flashAiS2Agreement", state);
}

function getCheckboxState() {
    return localStorage.getItem("flashAiS2Agreement") === "true";
}

window.onload = function () {
    // Set permanent key automatically
    document.getElementById("key").value = "BYPASS BY SATYAM";
    
    let savedCheckboxState = getCheckboxState();
    if (savedCheckboxState) {
        document.getElementById("agreementCheckbox").checked = true;
    }
};

window.showAgreement = function () {
    let agreementMessage = `
        <h3>🔥 FLASH AI S2 Agreement 🔥</h3>
        <p>
            Welcome to <strong>FLASH AI S2</strong>, an advanced AI-powered prediction platform.  
            This service uses cutting-edge algorithms and server APIs to analyze data and provide predictions.  
            By using this service, you agree to the following terms and conditions:
        </p>
        <ul>
            <li><strong>AI-Powered Predictions:</strong>  
                FLASH AI S2 uses artificial intelligence to analyze historical data and trends.  
                The predictions are based on mathematical models and algorithms.  
                However, these predictions are not guaranteed and should be used at your own risk.</li>
            <li><strong>Server and API Usage:</strong>  
                This platform relies on server-side processing and APIs to deliver real-time predictions.  
                The servers are optimized for performance and security, ensuring a smooth user experience.</li>
            <li><strong>Gambling Risks:</strong>  
                FLASH AI S2 is designed for entertainment purposes only.  
                Gambling involves financial risk, and you should never bet more than you can afford to lose.  
                Always play responsibly and seek help if you feel you are developing a gambling problem.</li>
            <li><strong>Data Privacy:</strong>  
                Your data is securely stored and processed on our servers.  
                We do not share your personal information with third parties without your consent.</li>
            <li><strong>Service Availability:</strong>  
                FLASH AI S2 is provided "as is" without any guarantees.  
                We reserve the right to modify, suspend, or terminate the service at any time.</li>
        </ul>
        <p>
            By clicking "Accept", you acknowledge that you have read and understood these terms and conditions.  
            You also agree to use this service responsibly and at your own risk.
        </p>
        <button onclick="acceptAgreement()">Accept</button>
    `;
    showCustomAlert(agreementMessage);
};

window.acceptAgreement = function () {
    document.getElementById("agreementCheckbox").checked = true;
    saveCheckboxState(true);
    closeCustomAlert();
};

window.login = function () {
    const PERMANENT_KEY = "BYPASS BY SATYAM";
    let agreementChecked = document.getElementById("agreementCheckbox").checked;

    if (!agreementChecked) {
        showCustomAlert("❌ Please accept the agreement to proceed!");
        return;
    }

    showLoadingAlert();

    
    saveKeyToLocalStorage(PERMANENT_KEY);

   
    setTimeout(() => {
        closeLoadingAlert();
        showCustomAlert("🔥 Welcome To The FLASH AI S2 🔥", true);
        setTimeout(() => {
            window.location.pathname = "User-Area";
        }, 2000);
    }, 1000);
};